#ifndef USERPAGES_H
#define USERPAGES_H

// User pages

// 
void set_active_values();
void get_active_values();

void userPage();
void filldynamicdata();

#endif
